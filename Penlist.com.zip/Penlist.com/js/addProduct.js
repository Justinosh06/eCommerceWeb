const addProductButton = document.getElementById('add-product-button'),
addProduct_close = document.getElementById('addProduct-close'),
addProductModal = document.getElementById('add-product-modal');

addProductButton.addEventListener('click', function() {
    addProductModal.style.display = 'flex';
});

addProduct_close.addEventListener('click', function() {
    addProductModal.style.display = 'none';
});

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == addProductModal) {
        addProductModal.style.display = "none";
    }
}