// get the radio buttons
const radioButtons = document.getElementsByName('PenType'),
reportTitle = document.getElementById('report-title'),
textTitle = localStorage.getItem('titleText');

if (textTitle == null){
    localStorage.setItem('titleText', 'Report');
}

function updateProductCard() {

    const PenType = document.querySelector('input[name="PenType"]:checked').value;
    let PenType_name;

    if (PenType === "") {
        PenType_name = "PenName";
    } else {
        PenType_name = document.querySelector('input[name="PenType"][value="' + PenType + '"] ~ input[name="PenName"]').value;
    }

    if (PenType_name === "PenName") {
        localStorage.setItem('titleText', 'Report');
        reportTitle.innerHTML = 'Report';
    } else {
        localStorage.setItem('titleText', 'Report of product: ' + PenType_name);
        reportTitle.innerHTML = 'Report of product: ' + PenType_name;
    }
  
    // update the URL with the selected values
    const urlSearchParams = new URLSearchParams(window.location.search);
    urlSearchParams.set('PenType', PenType);
    const newUrl = `${window.location.pathname}?${urlSearchParams.toString()}`;
    window.history.pushState({ path: newUrl }, '', newUrl);
    window.location.reload();
}

// add change event listeners to the radio buttons
radioButtons.forEach(function(radio) {
    radio.addEventListener('change', updateProductCard);
});

// Check for search bar parameter in URL
const urlSearchParams = new URLSearchParams(window.location.search);
const params = Object.fromEntries(urlSearchParams.entries());

  if (params.PenType) {
    const selectedRadioButton = document.querySelector(`input[name="PenType"][value="${params.PenType}"]`);
    if (selectedRadioButton) {
        reportTitle.innerHTML = textTitle;

        selectedRadioButton.checked = true;
    }
  }

const tabsBox = document.querySelector(".radio-btn"),
arrowIcons = document.querySelectorAll(".icon i");

const handleIcons = () => {
    let scrollVal = tabsBox.scrollLeft;
    let maxScrollableWidth = tabsBox.scrollWidth - tabsBox.clientWidth;
    arrowIcons[0].parentElement.style.display = scrollVal > 0 ? "flex" : "none";
    arrowIcons[1].parentElement.style.display = maxScrollableWidth > scrollVal ? "flex" : "none";
}

arrowIcons.forEach(icon => {
    icon.addEventListener("click", () => {
        // if clicked icon is left, reduce 350 from tabsBox scrollLeft else add
        tabsBox.scrollLeft += icon.id === "left" ? -200 : 200;
        setTimeout(() => handleIcons(), 50);
    });
});