const sidebar = body.querySelector("nav"),
      sidebarToggle = body.querySelector(".sidebar-toggle");

sidebarToggle.addEventListener("click", () =>{
    sidebar.classList.toggle("close");
});