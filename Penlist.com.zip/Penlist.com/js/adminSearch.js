const searchBar = document.getElementsByName('Search')[0];

searchBar.addEventListener('input', updateProduct);

// Check for search bar parameter in URL
const urlSearchParams = new URLSearchParams(window.location.search);
const params = Object.fromEntries(urlSearchParams.entries());
if (params.search) {
  searchBar.value = params.search;
}

let timeoutId;

function updateProduct() {
    // clear the previous timeout, if any
    clearTimeout(timeoutId);

    // get the search bar value
    const searchValue = searchBar.value;
  
    // update the URL with the selected values
    const urlSearchParams = new URLSearchParams(window.location.search);
    urlSearchParams.set('search', searchValue);
    const newUrl = `${window.location.pathname}?${urlSearchParams.toString()}`;
    window.history.pushState({ path: newUrl }, '', newUrl);

    // wait for 2 seconds of not typing before reloading the page
    timeoutId = setTimeout(() => {
        window.location.reload();
    }, 1500);
  }