// Get the modal
var editModal = document.getElementById("edit-product-modal");

// Get the button that opens the modal
var editBtns = document.getElementsByClassName("edit-product");

// When the user clicks on the button, open the modal
for (var i = 0; i < editBtns.length; i++) {
  editBtns[i].onclick = function() {
    var productId = this.getAttribute("data-id");
    editModal.style.display = "flex";

    // Store the display state of the modal in local storage
    localStorage.setItem('editModalDisplayState', 'flex');

    // Set the value of the hidden input field in the form to the id of the selected product
    document.getElementById("edit-product-id").value = productId;
    
    // update the URL with the selected product id
    const urlEditParams = new URLSearchParams(window.location.search);
    urlEditParams.set('id', productId);
    const newUrl = `${window.location.pathname}?${urlEditParams.toString()}`;
    window.history.pushState({ path: newUrl }, '', newUrl);
  }
}

// When the user clicks on the close button, close the modal and reload the page without the product id parameter
document.getElementById("editProduct-close").onclick = function() {
  // update the URL without the product id parameter
  const urlEditParams = new URLSearchParams(window.location.search);
  urlEditParams.delete('id');
  const newUrl = `${window.location.pathname}?${urlEditParams.toString()}`;
  window.history.pushState({ path: newUrl }, '', newUrl);

  // close the modal
  editModal.style.display = "none";

  // Store the display state of the modal in local storage
  localStorage.setItem('editModalDisplayState', 'none');

  // reload the page
  reloadPage();
}

// When the user clicks anywhere outside of the modal, close it and reload the page without the product id parameter
window.onclick = function(event) {
  if (event.target == editModal) {
    // update the URL without the product id parameter
    const urlEditParams = new URLSearchParams(window.location.search);
    urlEditParams.delete('id');
    const newUrl = `${window.location.pathname}?${urlEditParams.toString()}`;
    window.history.pushState({ path: newUrl }, '', newUrl);
    // close the modal
    editModal.style.display = "none";

    localStorage.setItem('editModalDisplayState', 'none');
    // reload the page
    reloadPage();
  }
}

// Edit Product Form
const editProductForm = document.getElementById('edit-product-form');
const editProductId = document.getElementById('edit-product-id');
const editProductName = document.getElementById('edit-product-name');
const editProductCategory = document.getElementById('edit-product-category');
const editProductImage = document.getElementById('file-input-edit');
const editProductColor = document.getElementById('edit-product-color');
const editProductPrice = document.getElementById('edit-product-price');

const editProductIcons = document.querySelectorAll('.edit-product');

editProductIcons.forEach(icon => {
  icon.addEventListener('click', function(event) {
    event.preventDefault();
    const productId = this.getAttribute('data-id');
    
    editProductId.value = productId;

    // update the URL with the selected values
    const urlEditParams = new URLSearchParams(window.location.search);
    urlEditParams.set('id', productId);
    const newUrl = `${window.location.pathname}?${urlEditParams.toString()}`;
    window.history.pushState({ path: newUrl }, '', newUrl);
    reloadPage();

  });
});

// Get the current display state of the modal from local storage
const currentDisplayState = localStorage.getItem('editModalDisplayState');

// Set the display state of the modal based on the current display state from local storage
if (currentDisplayState === 'flex') {
  editModal.style.display = 'flex';
} else {
  editModal.style.display = 'none';
}

// Function to reload the page and preserve the modal state and URL parameters
function reloadPage() {
  const urlEditParams = new URLSearchParams(window.location.search);
  const productId = urlEditParams.get('id');
  
  // If the productId is not set, do nothing
  if (!productId) {
    return;
  }
  
  // Set the value of the hidden input field in the form to the id of the selected product
  editProductId.value = productId;
  
  // Reload the page and preserve the modal state and URL parameters
  const newUrl = `${window.location.pathname}?id=${productId}`;
  window.history.pushState({ path: newUrl }, '', newUrl);
  location.reload();

  // Restore the previous display state of the modal
  editModal.style.display = currentDisplayState;
}