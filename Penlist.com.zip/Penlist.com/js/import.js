function deleteCategory(idJenis) {
    console.log("delete");
    if (confirm('Are you sure you want to delete this category?')) {
        // Send an AJAX request to delete the product
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                // Reload the page after the product is deleted
                location.reload();
            }
        };
        xhttp.open("POST", "deleteCategory.php", true);
        xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhttp.send("idJenis=" + idJenis);
    }
}