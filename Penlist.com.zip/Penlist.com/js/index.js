// Get the animated elements
const animatedElements = document.querySelectorAll(".card");

// Create the Intersection Observer object
const observer = new IntersectionObserver(entries => {
  // Check if the element is visible
  if (entries[0].isIntersecting) {
    // Add the class to trigger the animation for each element
    animatedElements.forEach(element => element.classList.add("animated"));
    // Disconnect the observer to avoid further triggers
    observer.disconnect();
  }
});

// Observe each element
animatedElements.forEach(element => observer.observe(element));