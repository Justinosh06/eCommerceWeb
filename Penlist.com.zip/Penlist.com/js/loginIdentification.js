let isLoggedIn = false; // change to true if user is logged in

if (isLoggedIn) {
  document.getElementById("login-li").style.display = "none";
  document.getElementById("logout-li").style.display = "block";
  document.getElementById("profile-li").style.display = "block";
}
 else {
  document.getElementById("login-li").style.display = "block";
  document.getElementById("logout-li").style.display = "none";
  document.getElementById("profile-li").style.display = "none";
}

document.getElementById("logout-link").addEventListener("click", function() {
  isLoggedIn = false;
  document.getElementById("login-li").style.display = "block";
  document.getElementById("logout-li").style.display = "none";
  document.getElementById("profile-li").style.display = "none";
  document.getElementById("cart-li").style.display = "none";
});

document.getElementById("login-li").addEventListener("click", function() {
  isLoggedIn = true;
  document.getElementById("login-li").style.display = "none";
  document.getElementById("logout-li").style.display = "block";
  document.getElementById("profile-li").style.display = "block";
  document.getElementById("cart-li").style.display = "block";
});