function togglePasswordVisibility(fieldId) {
    console.log(fieldId);

    var passwordField = document.getElementById(fieldId);
    var visibilityButton = document.getElementById(`pswd-visibility-${fieldId}`);
  
    if (passwordField && visibilityButton) {
      if (passwordField.type === 'password') {
        console.log(fieldId);
        passwordField.type = 'text';
        visibilityButton.innerHTML = '<i class="fa-solid fa-eye"></i>';
      } else {
        console.log(fieldId);
        passwordField.type = 'password';
        visibilityButton.innerHTML = '<i class="fa-solid fa-eye-slash"></i>';
      }
    }
  }
  