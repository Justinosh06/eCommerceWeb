// get the radio buttons and search bar
const radioButtons = document.getElementsByName('PenType');
const searchBar = document.getElementsByName('search')[0];

let timeoutId;

function updateProductCards() {
  // clear the previous timeout, if any
  clearTimeout(timeoutId);

  // get the selected radio button value and search bar value
  const penType = document.querySelector('input[name="PenType"]:checked').value;
  const searchValue = searchBar.value;

  // update the URL with the selected values
  const urlSearchParams = new URLSearchParams(window.location.search);
  urlSearchParams.set('PenType', penType);
  urlSearchParams.set('search', searchValue);
  const newUrl = `${window.location.pathname}?${urlSearchParams.toString()}`;
  window.history.pushState({ path: newUrl }, '', newUrl);

  // wait for 2 seconds of not typing before reloading the page
    timeoutId = setTimeout(() => {
        window.location.reload();
    }, 1500);
}

function updateProductCard() {

  // get the selected radio button value and search bar value
  const penType = document.querySelector('input[name="PenType"]:checked').value;
  const searchValue = searchBar.value;

  // update the URL with the selected values
  const urlSearchParams = new URLSearchParams(window.location.search);
  urlSearchParams.set('PenType', penType);
  urlSearchParams.set('search', searchValue);
  const newUrl = `${window.location.pathname}?${urlSearchParams.toString()}`;
  window.history.pushState({ path: newUrl }, '', newUrl);
  window.location.reload();
}

// add change event listeners to the radio buttons and search bar
radioButtons.forEach(function(radio) {
  radio.addEventListener('change', updateProductCard);
});
searchBar.addEventListener('input', updateProductCards);

// Check for search bar parameter in URL
const urlSearchParams = new URLSearchParams(window.location.search);
const params = Object.fromEntries(urlSearchParams.entries());
if (params.search) {
  searchBar.value = params.search;
}

if (params.PenType) {
  const selectedRadioButton = document.querySelector(`input[name="PenType"][value="${params.PenType}"]`);
  if (selectedRadioButton) {
    selectedRadioButton.checked = true;
  }
}

// Get the animated elements
const animatedElements = document.querySelectorAll(".card");

// Create the Intersection Observer object
const observer = new IntersectionObserver(entries => {
  // Check if the element is visible
  if (entries[0].isIntersecting) {
    // Add the class to trigger the animation for each element
    animatedElements.forEach(element => element.classList.add("animated"));
    // Disconnect the observer to avoid further triggers
    observer.disconnect();
  }
});

// Observe each element
animatedElements.forEach(element => observer.observe(element));