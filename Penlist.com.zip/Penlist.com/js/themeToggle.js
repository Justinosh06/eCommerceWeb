const body = document.querySelector("body");
const modeToggle_dark = body.querySelector(".mode-toggle-dark");
const modeToggle_theme = body.querySelector(".mode-toggle-theme");

modeToggle_dark.addEventListener("click", () =>{
    body.classList.toggle("dark");
    body.classList.remove("theme");
});

modeToggle_theme.addEventListener("click", () =>{
    body.classList.toggle("theme");
    body.classList.remove("dark");
});
