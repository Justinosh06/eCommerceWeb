<?php
include '../php/connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = mysqli_real_escape_string($con, $_POST['name']);
    $category = mysqli_real_escape_string($con, $_POST['category']);
    $image = file_get_contents($_FILES['img']['tmp_name']);
    $imageData = mysqli_real_escape_string($con, $image);
    $color = mysqli_real_escape_string($con, $_POST['color']);
    $price = mysqli_real_escape_string($con, $_POST['price']);
    $idAdmin = $_SESSION['admin_id'];

    // check if the file size is too large
    if ($_FILES["img"]["size"] > 500000000) {
        echo "<script>alert('Sorry, your file is too large.'); window.location.href = 'admindashboard.php';</script>";
        $uploadOk = 0;
    }

    $sql = "INSERT INTO produk (namaProduk, idJenis, imejProduk, warnaProduk, hargaProduk, idAdmin) VALUES ('$name', $category, '$imageData', '$color', $price, $idAdmin)";

    if (mysqli_query($con, $sql)) {
        echo '<script>alert("Product added successfully."); window.location.href = "admindashboard.php";</script>';
    } else {
        echo "Error: " . mysqli_error($con);
    }
}
?>

if()