<div id="add-product-modal" style="display: none;">
    <form method="post" action="addProduct.php" enctype="multipart/form-data">
        <div class="formHeader">
            <label class = "form-title">Add Product</label>
            <button type="button" id = "addProduct-close"><i class="fa-solid fa-xmark"></i></button>
        </div>  

        <label for="name">Name</label>
        <input type="text" name="name" id="name" placeholder="Name" pattern = ".{1, 50}" oninvalid = "setCustomValidity('Please fill in and do not exceed 50 characters')" oninput = "setCustomvalidity('')">

        <label for="category">Category</label>
        <select name="category" id="category">

        <?php
        $query = mysqli_query($con, "SELECT idJenis, namaJenis FROM `jenis`");

        if (!$query) {
            echo "Error: " . mysqli_error($con);
            exit();
        }

        while ($row = mysqli_fetch_assoc($query)) {
            foreach ($row as $key => $value) {
                if ($key == 'namaJenis'){
                    echo '<option value="'.$row["idJenis"].'">'.$value.'</option>';
                }
            }
        }
        ?>

        </select>
        
        <label for="img">Image</label>
        <div class="div" id="drop-zone">
            <label for="file" class="custom-file-upload"><span>Drag and drop your file here<span></label>
        </div>
        <input type="file" accept=".png" name="img" id="file-input" onchange="loadFile(event)" required>
        <img id="output" src="#" alt="Preview Image" style="display: none;">

        <label for="color" class = "form-color">Color</label>
        <input type="text" name="color" id="color" placeholder="Color" pattern = ".{1, }" oninvalid = "setCustomValidity('Please fill in')" oninput = "setCustomvalidity('')">

        <label for="price">Price</label>
        <input type="text" name="price" id="price" placeholder="Price" step="0.01" min="0">

        <button type="submit">Add Product</button>
    </form>
</div>

<script>
var loadFile = function(event) {
    var output = document.getElementById('output');
    output.style.display = "block";
    output.src = URL.createObjectURL(event.target.files[0]);
};
</script>

<script>
    const dropZone = document.getElementById('drop-zone');
    const fileInput = document.getElementById('file-input');

    ['dragover', 'dragenter'].forEach(eventName => {
    dropZone.addEventListener(eventName, e => {
        e.preventDefault();
        dropZone.classList.add('highlight');
    }, false);
    });

    ['dragleave', 'dragend'].forEach(eventName => {
    dropZone.addEventListener(eventName, e => {
        e.preventDefault();
        dropZone.classList.remove('highlight');
    }, false);
    });

    dropZone.addEventListener('drop', e => {
    e.preventDefault();
    dropZone.classList.remove('highlight');
    const file = e.dataTransfer.files[0];
    fileInput.files = e.dataTransfer.files;
    fileInput.dispatchEvent(new Event('change'));
    }, false);
</script>