<?php
include '../php/connect.php';

$idUsers = $_SESSION['user_id'];
$location = $_POST['location'];
$idProduct = $_POST['idProduct'];

$sql = "INSERT INTO `pemilihan` (idPengguna, idProduk) VALUES ($idUsers, $idProduct)";
$validation = "SELECT * FROM `pemilihan` WHERE idPengguna = $idUsers AND idProduk = $idProduct";


$validity = mysqli_query($con, $validation);
$rows_count = mysqli_num_rows($validity);

if ($rows_count > 0){
    echo "<script>alert('Product already exist in the cart!');</script>";
    echo "<script>setTimeout(function(){ window.location.href = 'searchpage.php'; }, 10);</script>";
} else {
    $result = mysqli_query($con, $sql);

    if ($result){
        echo "<script>alert('Added successful!');</script>";
        echo "<script>setTimeout(function(){ window.location.href = '".$location."'; }, 10);</script>";
    } else {
        echo "<script>alert('Adding unsuccessful!');</script>";
        echo "<script>setTimeout(function(){ window.location.href = '".$location."'; }, 10);</script>";
    }
}
?>