<?php
    include '../php/connect.php';
?>

<!DOCTYPE HTML>
<html>
  <head>
    <meta charset = "utf-8">
    <meta name = "viewport" content = "width = device-width, initial-scale = 1.0">
    <meta http-equiv = "X-UA-Compatible" content = "IE = edge">

    <!--title-->
    <title>Analytics | PenList</title>
    <!--shortcut icon-->
    <link rel = "Shortcut Icon" type = "image/png" href = "../image/favicon.png">

    <link href = "https://fonts.googleapis.com" rel = "preconnect">
    <link href = "https://fonts.gstatic.com" crossorigin rel = "preconnect">

    <!--Icons Source-->
    <link rel="stylesheet" href="../fontawesome-free-6.4.0-web/css/all.min.css">

    <!--import fonts-->
    <link href = "https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800;900&display=swap" rel = "stylesheet">

    <!--import font icons-->
    <script src = "https://kit.fontawesome.com/f3ce044c74.js" crossorigin = "anonymous"></script>
    <link rel = "stylesheet" href = "https://kit.fontawesome.com/f3ce044c74.css" crossorigin = "anonymous">

    <!--link to external css file-->
    <link href = "../css/admindashboard.css" rel = "stylesheet">
    <link href = "../css/adminNavbar.css" rel = "stylesheet">
    <link href = "../css/adminAnalytics.css" rel = "stylesheet">
    <link href = "../css/adminFilter.css" rel = "stylesheet">


  </head>
  <body>

    <div class="navbar">
        <?php
        include "../html/adminNavbar.html";
        ?>
    </div>

    <section class="dashboard">

        <?php
        include "../html/adminTop.html";
        ?>

        <div class="main">
        <?php
        include "../php/adminFilter.php";
        ?>

        <div class="report-section" id = "report-section">
        <div class="report-header">
            <i class="fa-solid fa-chart-simple"></i>
            <h1 class="title" id="report-title">Report</h1>
        </div>

        <div class="report-table">
        <table>
            <thead>
            <tr>
                <th>ID Pengguna</th>
                <th>Nama Pengguna</th>
                <th>Gambar</th>
                <th>Nama Produk</th>
                <th>Jenis</th>
                <th>Harga</th>
            </tr>
            </thead>
            <?php

                if (isset($_GET['PenType'])) {
                    $pentype = mysqli_real_escape_string($con, $_GET['PenType']);
                } else {
                    $pentype = "";
                }
                
                if (!empty($pentype)){
                    $sql = "SELECT * FROM pemilihan AS table1
                        INNER JOIN produk AS table2
                        INNER JOIN pengguna AS table3
                        INNER JOIN jenis AS table4
                        INNER JOIN admin AS table5
                        ON table1.idProduk = table2.idProduk 
                        AND table1.idPengguna = table3.idPengguna 
                        AND table2.idJenis = table4.idJenis
                        AND table2.idAdmin = table5.idAdmin
                        WHERE table2.idJenis = $pentype;";
                } else {
                    $sql = "SELECT * FROM pemilihan AS table1
                        INNER JOIN produk AS table2
                        INNER JOIN pengguna AS table3
                        INNER JOIN jenis AS table4
                        INNER JOIN admin AS table5
                        ON table1.idProduk = table2.idProduk 
                        AND table1.idPengguna = table3.idPengguna 
                        AND table2.idJenis = table4.idJenis
                        AND table2.idAdmin = table5.idAdmin;";
                }

                $result = mysqli_query($con, $sql);
                $resultCheck = mysqli_num_rows($result);
                $i = 0;
                if ($resultCheck > 0){
                while ($row = mysqli_fetch_assoc($result)){ $i++?>
                    <tr>
                        <td><?php echo $row['idPengguna']; ?></td>
                        <td><?php echo $row['namaPengguna']; ?></td>
                        <td><div class = "table-img"><img src="data:Images/png;base64,<?php echo base64_encode($row['imejProduk']); ?>"></div></td>
                        <td><?php echo $row['namaProduk']; ?></td>
                        <td><?php echo $row['namaJenis']; ?></td>
                        <td>RM<?php echo $row['hargaProduk']; ?></td>
                    </tr>
                <?php 
                    } 
                } 
                ?>
        </table>
        </div>
        </div>
        <button title = "Print" class = "print" onclick="printElement('report-section')"><i class="fa-solid fa-print"></i></button>
        </div>

    </section>
    <script type="text/javascript" src = "../js/themeToggle.js"></script>
    <script type="text/javascript" src = "../js/adminNavbar.js"></script>
    <script type="text/javascript" src = "../js/adminAnalytics.js"></script>
  </body>
</html>

<script>
function printElement(elementId) {
    var result = confirm("Do you want to print this page?");

    if (result == true) {
        var isPrinting = window.print();
        if (isPrinting) {
            // Add CSS rule for portrait orientation
            var css = '@media print { @page { size: portrait; } }';
            var style = document.createElement('style');
            var printContents = document.getElementById(elementId).innerHTML;
            var originalContents = document.body.innerHTML;
            style.appendChild(document.createTextNode(css));
            document.head.appendChild(style);

            document.body.innerHTML = printContents;
            window.print();
            document.body.innerHTML = originalContents;
        }
    } else {
        return;
    }
}
</script>