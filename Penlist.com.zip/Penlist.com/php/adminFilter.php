<?php
$query = mysqli_query($con, "SELECT * FROM `jenis` GROUP BY idJenis");

echo '<div class = "radio-section">';
echo '<div class = "icon" style = "display: none;"><i id = "left" class = "fa-solid fa-chevron-left"></i></div>';

echo '<div class = "radio-btn">';

echo '<input type = "radio" name = "PenType" value = "" id = "all" checked = "checked">';
echo '<input type = "hidden" name = "PenName" value = "" id = "PenName">';
echo '<label for = "all"><div class="dot"></div><span>All</span></label>';

while ($row = mysqli_fetch_assoc($query)) {
    $idJenis = $row['idJenis'];
    foreach ($row as $key => $value) {
        if ($key == 'namaJenis'){
            echo '<input type = "radio" name = "PenType" value = "'.$idJenis.'" id = "'.$value.'">';
            echo '<input type = "hidden" name = "PenName" value = "'.$value.'" id = "'.$idJenis.' PenName">';
            echo '<label for = "'.$value.'"><div class="dot"></div><span>'.$value.'</span></label>';
        }
    }
}

echo '</div>';

echo '<div class = "icon"><i id = "right" class = "fa-solid fa-chevron-right"></i></div>';
echo '</div>';
?>