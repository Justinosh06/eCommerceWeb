<?php
include "../php/connect.php";
?>


<?php

if (isset($_GET['search']) && !empty($_GET['search'])) {
  $Search = mysqli_real_escape_string($con, $_GET['search']);
} else {
  $Search = "";
}


if (!empty($Search)){
  $query = mysqli_query($con, "SELECT idProduk, imejProduk, namaProduk, jenis.namaJenis, warnaProduk, hargaProduk FROM `produk` INNER JOIN `jenis` ON produk.idJenis = jenis.idJenis WHERE namaProduk LIKE '%$Search%' ORDER BY idProduk ASC");
} else {
  $query = mysqli_query($con, "SELECT idProduk, imejProduk, namaProduk, jenis.namaJenis, warnaProduk, hargaProduk FROM `produk` INNER JOIN `jenis` ON produk.idJenis = jenis.idJenis ORDER BY idProduk ASC");
}

if (!$query) {
    echo "Error: " . mysqli_error($con);
    exit();
}

echo '<div class = "product-section" id = "product-section">';
echo '<div class = "productHeader">';
echo '<i class="fa-solid fa-cubes"></i>';
echo '<span class = "product-title">Product</span>';

echo '<div class = "search-box">';
echo '<i class="fa-solid fa-magnifying-glass"></i>';
echo '<input name = "Search" type = "text" placeholder = "Search here...">';
echo '</div>';
echo '</div>';

echo '<div class = "product">';
echo '<table>';
echo '<thead>';
echo '<tr>';
echo '<th>ID Product</th>';
echo '<th></th>';
echo '<th>Name</th>';
echo '<th>Category</th>';
echo '<th>Color</th>';
echo '<th>Price</th>';
echo '<th><button id="add-product-button"><span class = "addProduct">Add <i class="fa-solid fa-cubes"></i> Product</span></button></th>';
echo '</tr>';
echo '</thead>';
echo '<tbody>';

while ($row = mysqli_fetch_assoc($query)) {
    echo '<tr>';

    foreach ($row as $key => $value) {
        if ($key == 'idProduk'){
            echo '<td class = "idProduk"><strong>'.$value.'</strong></td>';
        }
        else if ($key == 'imejProduk'){
            echo '<td class = "imejProduk">';
            echo '<img src = "data:image/png;base64,'.base64_encode($value).'" alt = "...">';
            echo '</td>';
        }
        else if ($key == 'namaProduk'){
            echo '<td class = "namaProduk">'.$value.'</td>';
        }
        else if ($key == 'namaJenis'){
            echo '<td class = "namaJenis">'.$value.'</td>';
        }
        else if ($key == 'warnaProduk'){
            echo '<td class = "warnaProduk"><p class = "color '.$value.'-colored">'.$value.'</p></td>';
        }
        else if ($key == 'hargaProduk'){
            echo '<td class = "hargaProduk"><strong> RM '.$value.' </strong></td>';
        }
    }
    echo '<td><div class = "product-utility">';
    echo '<i class="fa-solid fa-trash" id="delete-product" onclick="deleteProduct('.$row['idProduk'].')"></i>';
    echo '<i class="fa-solid fa-pen-to-square edit-product" id="edit-product" data-id = "'.$row['idProduk'].'"></i>';
    echo '<div></td>';

    echo '</tr>';
}

echo '</tbody>';
echo '</table>';
echo '</div>';
echo '</div>';

include '../php/addProductForm.php';
include '../php/editProductForm.php';
?>