<?php
    include '../php/connect.php';
?>

<!DOCTYPE HTML>
<html>
  <head>
    <meta charset = "utf-8">
    <meta name = "viewport" content = "width = device-width, initial-scale = 1.0">
    <meta http-equiv = "X-UA-Compatible" content = "IE = edge">

    <!--title-->
    <title>Profile | PenList</title>
    <!--shortcut icon-->
    <link rel = "Shortcut Icon" type = "image/png" href = "../image/favicon.png">

    <link href = "https://fonts.googleapis.com" rel = "preconnect">
    <link href = "https://fonts.gstatic.com" crossorigin rel = "preconnect">

    <!--Icons Source-->
    <link rel="stylesheet" href="../fontawesome-free-6.4.0-web/css/all.min.css">

    <!--import fonts-->
    <link href = "https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800;900&display=swap" rel = "stylesheet">

    <!--import font icons-->
    <script src = "https://kit.fontawesome.com/f3ce044c74.js" crossorigin = "anonymous"></script>
    <link rel = "stylesheet" href = "https://kit.fontawesome.com/f3ce044c74.css" crossorigin = "anonymous">

    <!--link to external css file-->
    <link href = "../css/admindashboard.css" rel = "stylesheet">
    <link href = "../css/adminNavbar.css" rel = "stylesheet">
    <link href = "../css/adminAnalytics.css" rel = "stylesheet">
    <link href = "../css/adminFilter.css" rel = "stylesheet">


  </head>
  <body>

    <div class="navbar">
        <?php
        include "../html/adminNavbar.html";
        ?>
    </div>

    <section class="dashboard">

        <?php
        include "../html/adminTop.html";
        ?>


    </section>
    <script type="text/javascript" src = "../js/themeToggle.js"></script>
    <script type="text/javascript" src = "../js/adminNavbar.js"></script>
  </body>
</html>