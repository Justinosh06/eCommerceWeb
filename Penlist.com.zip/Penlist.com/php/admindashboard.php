<?php
include '../php/connect.php';
?>

<!DOCTYPE HTML>
<html>
  <head>
    <meta charset = "utf-8">
    <meta name = "viewport" content = "width = device-width, initial-scale = 1.0">
    <meta http-equiv = "X-UA-Compatible" content = "IE = edge">

    <!--title-->
    <title>Admin Dashboard | PenList</title>
    <!--shortcut icon-->
    <link rel = "Shortcut Icon" type = "image/png" href = "../image/favicon.png">

    <link href = "https://fonts.googleapis.com" rel = "preconnect">
    <link href = "https://fonts.gstatic.com" crossorigin rel = "preconnect">

    <!--Icons Source-->
    <link rel="stylesheet" href="../fontawesome-free-6.4.0-web/css/all.min.css">

    <!--import fonts-->
    <link href = "https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800;900&display=swap" rel = "stylesheet">

    <!--import font icons-->
    <script src = "https://kit.fontawesome.com/f3ce044c74.js" crossorigin = "anonymous"></script>
    <link rel = "stylesheet" href = "https://kit.fontawesome.com/f3ce044c74.css" crossorigin = "anonymous">

    <!--link to external css file-->
    <link href = "../css/admindashboard.css" rel = "stylesheet">
    <link href = "../css/adminNavbar.css" rel = "stylesheet">
    <link href = "../css/adminProductlist.css" rel = "stylesheet">
    <link href = "../css/addProductForm.css" rel = "stylesheet">
    <link href = "../css/editProductForm.css" rel = "stylesheet">


  </head>
  <body>

    <div class="navbar">
        <?php
        include "../html/adminNavbar.html";
        ?>
    </div>

    <section class="dashboard">
        <?php
        include "../html/adminTop.html";
        ?>

    <div class="main">
        <section class = "analytics">
            <div class = "dash-content">
                <div class="overview">
                    <div class="title">
                        <i class="fa-solid fa-gauge-simple-high"></i>
                        <span class="text">Dashboard</span>
                    </div>

                    <div class="boxes">
                        <div class="box box1">
                            <div class="icon">
                                <i class="fa-solid fa-users"></i>
                            </div>
                            <div class="text-section">
                                <span class="text">Total Users</span>

                                <?php
                                require '../php/connect.php';

                                $query = mysqli_query($con, "SELECT Count(idPengguna) FROM `pengguna`");
                                $result = mysqli_fetch_assoc($query);
                            
                                $count = $result['Count(idPengguna)'];

                                echo '<span class = "number">'.$count.'</span>';
                                ?>
                            </div>
                        </div>

                        <div class="box box2">
                            <div class="icon">
                                <i class="fa-solid fa-clipboard-user"></i>
                            </div>
                            <div class="text-section">
                                <span class="text">Total Admins</span>

                                <?php
                                require '../php/connect.php';

                                $query = mysqli_query($con, "SELECT Count(idAdmin) FROM `admin`");
                                $result = mysqli_fetch_assoc($query);
                            
                                $count = $result['Count(idAdmin)'];

                                echo '<span class = "number">'.$count.'</span>';
                                ?>
                            </div>
                        </div>

                        <div class="box box3">
                            <div class="icon">
                                <i class="fa-solid fa-cubes"></i>
                            </div>
                            <div class="text-section">
                                <span class="text">Total Products</span>

                                <?php
                                require '../php/connect.php';

                                $query = mysqli_query($con, "SELECT Count(idProduk) FROM `produk`");
                                $result = mysqli_fetch_assoc($query);
                            
                                $count = $result['Count(idProduk)'];

                                echo '<span class = "number">'.$count.'</span>';
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <div class="products">
            <?php
            include "../php/adminProductlist.php";
            ?>
        </div>

    </div>      

    </section>


    <script type="text/javascript" src = "../js/themeToggle.js"></script>
    <script type="text/javascript" src = "../js/adminNavbar.js"></script>
    <script type="text/javascript" src = "../js/adminSearch.js"></script>
    <script type="text/javascript" src = "../js/deleteProduct.js"></script>
    <script type="text/javascript" src = "../js/addProduct.js"></script>
    <script type="text/javascript" src = "../js/editProduct.js"></script>
  </body>
</html>