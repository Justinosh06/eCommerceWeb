<!DOCTYPE HTML>
<html>
  <head>
    <meta charset = "utf-8">
    <meta name = "viewport" content = "width = device-width, initial-scale = 1.0">
    <meta http-equiv = "X-UA-Compatible" content = "IE = edge">

    <!--title-->
    <title>Cart | PenList</title>
    <!--shortcut icon-->
    <link rel = "Shortcut Icon" type = "image/png" href = "../image/favicon.png">

    <link href = "https://fonts.googleapis.com" rel = "preconnect">
    <link href = "https://fonts.gstatic.com" crossorigin rel = "preconnect">

    <!--Icons Source-->
    <link rel="stylesheet" href="../fontawesome-free-6.4.0-web/css/all.min.css">

    <!--import fonts-->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">

    <!--link to external css file-->
    <link href = "../css/navbar.css" rel = "stylesheet">
    <link href = "../css/footer.css" rel = "stylesheet">
    <link href = "../css/cart.css" rel = "stylesheet">
  </head>
  <body>
    <div class = "navigationBar">
      <?php
      include "../php/navbar.php";
      ?>
    </div>

    <div class="cartHeader">
      <h1 class="title">Cart</h1>
    </div>

    <div class="print-section" id="print-section">
    <div class="items" id = "items">
      <table>
        <thead>
          <tr>
            <th></th>
            <th>Product</th>
            <th></th>
            <th></th>
            <th class = "price">Price</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <?php
          $idUser = $_SESSION['user_id'];

          $sql = "SELECT * FROM pemilihan AS table1
          INNER JOIN produk AS table2 ON table1.idProduk = table2.idProduk
          INNER JOIN pengguna AS table3 ON table1.idPengguna = table3.idPengguna
          INNER JOIN jenis AS table4 ON table2.idJenis = table4.idJenis
          WHERE table3.idPengguna = '$idUser'";

          $countProduct = "SELECT COUNT(DISTINCT idProduk) AS num_items
                 FROM (
                    SELECT idProduk
                    FROM pemilihan
                    WHERE idPengguna = '$idUser'
                  ) AS subquery";


          $totalPrice = "SELECT SUM(subquery.hargaProduk) AS total_price
                FROM (
                  SELECT p.hargaProduk
                  FROM pemilihan AS pm
                  INNER JOIN produk AS p ON pm.idProduk = p.idProduk
                  WHERE pm.idPengguna = '$idUser'
                ) AS subquery";

          $result = mysqli_query($con, $sql);
          $resultCheck = mysqli_num_rows($result);

          $i = 0;

          if ($resultCheck > 0){
            while ($row = mysqli_fetch_assoc($result)) { 
              $i++;
              echo '<tr>';
              echo '<td>'.$i.'</td>';
              echo '<td><div class = "table-img"><img src="data:Images/png;base64,'.base64_encode($row["imejProduk"]).'"></div></td>';
              echo '<td>'.$row['namaProduk'].'</td>';
              echo '<td>'.$row['namaJenis'].'</td>';
              echo '<td>RM'.$row['hargaProduk'].'</td>';
              echo '<td><button class = "delete-cart" onclick = "deleteCart('.$row['idProduk'].')"><i class="fa-solid fa-trash"></i></button></td>';
              echo '</tr>';
            }
          }

          $finalCountProduct = mysqli_query($con, $countProduct);
          $finalTotalPrice = mysqli_query($con, $totalPrice);

          $noProduct = mysqli_fetch_assoc($finalCountProduct);
          $Price = mysqli_fetch_assoc($finalTotalPrice);


          echo '<tr>';
          echo '<td></td>';
          echo '<td></td>';
          echo '<td class = "total"><strong>Total </strong></td>';
          echo '<td>'.$noProduct['num_items'].' <i class="fa-solid fa-boxes-stacked"></i></td>';
          echo '<td>RM'.$Price['total_price'].'</td>';
          ?>
          <td><button class = "print" onclick="printElement('print-section')"><i class="fa-solid fa-print"></i> Print</button></td>
          <?php
          echo '</tr>';
          ?>
        </tbody>
      </table>
    </div>
    </div>

    <footer>
      <?php
      include "../html/footer.html";
      ?>
    </footer>

    <script type = "text/javascript" src = "../js/navbar.js"></script>
    <script type = "text/javascript" src = "../js/loginIdenfication.js"></script>
    <script type = "text/javascript" src = "../js/deleteCart.js"></script>

  </body>
</html>


<script>
function printElement(elementId) {
  var printContents = document.getElementById(elementId).innerHTML;
  var originalContents = document.body.innerHTML;
  document.body.innerHTML = printContents;

  // Add CSS rule for portrait orientation
  var css = '@media print { @page { size: portrait; } }';
  var style = document.createElement('style');
  style.appendChild(document.createTextNode(css));
  document.head.appendChild(style);

  window.print();
  document.body.innerHTML = originalContents;
}
</script>