<?php
    if(session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    // Connect to the database
    $con = mysqli_connect('localhost', 'root', '', 'penlist.com');

    // Check for connection errors
    if(!$con){
        die('Connection failed: ' . mysqli_connect_error());
    }
?>




