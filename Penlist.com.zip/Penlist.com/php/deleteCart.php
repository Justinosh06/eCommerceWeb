<?php
include "../php/connect.php";

$idPengguna = $_SESSION['user_id'];
$idProduk = $_POST['idProduk'];

$query = mysqli_query($con, "DELETE FROM `pemilihan` WHERE idProduk = '$idProduk' AND idPengguna = '$idPengguna'");

if (!$query) {
    echo "Error: " . mysqli_error($con);
    exit();
}
?>