<?php
include "../php/connect.php";

$idJenis = $_POST['idJenis'];

$query = mysqli_query($con, "DELETE FROM `jenis` WHERE idJenis= '$idJenis'");

if (!$query) {
    echo "Error: " . mysqli_error($con);
    exit();
}
?>