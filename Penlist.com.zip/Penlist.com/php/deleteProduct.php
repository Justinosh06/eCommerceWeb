<?php
include "../php/connect.php";

$idProduk = $_POST['idProduk'];

$query = mysqli_query($con, "DELETE FROM `produk` WHERE idProduk = '$idProduk'");

if (!$query) {
    echo "Error: " . mysqli_error($con);
    exit();
}
?>
