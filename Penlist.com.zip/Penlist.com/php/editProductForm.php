<?php
    // Retrieve the selected product's data from the database
    $productId = isset($_GET['id']) ? intval($_GET['id']) : 0;
    $query = mysqli_query($con, "SELECT * FROM `produk` WHERE idProduk = $productId");
    $productData = mysqli_fetch_assoc($query);

    $imageData = $productData['imejProduk'];
    $base64Image = base64_encode($imageData);
    $imageSrc = 'data:image/png;base64,' . $base64Image;

    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }
?>

<div id="edit-product-modal" style="display: none;">
    <form method="post" id = "edit-product-form" action = "../php/editproduct.php" enctype="multipart/form-data">
        <div class="formHeader">
            <label class = "form-title">Edit Product</label>
            <button type="button" id = "editProduct-close"><i class="fa-solid fa-xmark"></i></button>
        </div>

        <label for="name">Name</label>
        <input type="text" name="name" id="edit-product-name" placeholder="Name" pattern = "^.{1,50}$" oninvalid = "setCustomValidity('Please fill in and do not exceed 50 characters')" oninput = "setCustomvalidity('')" value="<?php echo $productData['namaProduk']; ?>">

        <label for="category">Category</label>
        <select name="category" id="edit-product-category">

        <?php
        $category_query = mysqli_query($con, "SELECT * FROM `jenis`");

        while ($categoryData = mysqli_fetch_assoc($category_query)) {
            if ($categoryData['idJenis'] == $productData['idJenis']) {
                echo '<option value="'.$categoryData['idJenis'].'" selected>'.$categoryData['namaJenis'].'</option>';
            } else {
                echo '<option value="'.$categoryData['idJenis'].'">'.$categoryData['namaJenis'].'</option>';
            }
        }
        ?>

        </select>
        
        <label for="img">Image</label>
        <div class="div" id="drop-zone">
            <label for="file" class="custom-file-upload"><span>Drag and drop your file here<span></label>
        </div>
        <input type="file" accept=".png" name="img" id="file-input-edit" value="<?php echo $imageSrc; ?>" onchange="loadFile(event)">
        <img id="output" src="#" alt="Preview Image" style="display: none;">

        <label for="color" class = "form-color">Color</label>
        <input type="text" name="color" id="edit-product-color" placeholder="Color" pattern = ".{1, }" oninvalid = "setCustomValidity('Please fill in')" oninput = "setCustomvalidity('')" value="<?php echo $productData['warnaProduk']; ?>">

        <label for="price">Price</label>
        <input type="text" name="price" id="edit-product-price" placeholder="Price" step="0.01" min="0" value="<?php echo $productData['hargaProduk']; ?>">

        <input type="hidden" id = "edit-product-id" name="id" value = "<?php echo $productId; ?>">

        <button type="submit" name = "submit">Edit Product</button>
    </form>
</div>


<script>
var loadFile = function(event) {
    var output = document.getElementById('output');
    var base64ImgInput = document.getElementById('file-input-edit');
    output.style.display = "block";
    output.src = URL.createObjectURL(event.target.files[0]);

    // convert the selected image file to a base64 encoded string
    var reader = new FileReader();
    reader.onload = function(event) {
        base64ImgInput.value = event.target.result;
    };
    reader.readAsDataURL(event.target.files[0]);
};
</script>

<script>
    const dropZone = document.getElementById('drop-zone');
    const fileInput = document.getElementById('file-input-edit');

    ['dragover', 'dragenter'].forEach(eventName => {
    dropZone.addEventListener(eventName, e => {
        e.preventDefault();
        dropZone.classList.add('highlight');
    }, false);
    });

    ['dragleave', 'dragend'].forEach(eventName => {
    dropZone.addEventListener(eventName, e => {
        e.preventDefault();
        dropZone.classList.remove('highlight');
    }, false);
    });

    dropZone.addEventListener('drop', e => {
    e.preventDefault();
    dropZone.classList.remove('highlight');
    const file = e.dataTransfer.files[0];
    fileInput.files = e.dataTransfer.files;
    fileInput.dispatchEvent(new Event('change'));
    }, false);
</script>