<?php 
        include '../php/connect.php';


        if (!$con) {
            die("Connection failed: " . mysqli_connect_error());
        }
        
        if(isset($_POST['submit'])) {
            echo "console.log('submitted');";

            $productId = $_POST['id'];

            $query = mysqli_query($con, "SELECT * FROM `produk` WHERE idProduk = $productId");
            $row = mysqli_fetch_assoc($query);

        if (isset($_POST['name'])) {
            $namaProduk = $_POST['name'];
        } else {
            $namaProduk = $row['namaProduk'];
        }
        if (isset($_POST['price'])) {
            $harga = $_POST['price'];
        } else {
            $harga = $row['hargaProduk'];
        }
        if (isset($_POST['color'])) {
            $warna = $_POST['color'];
        } else {
            $warna = $row['warnaProduk'];
        }
        if (isset($_POST['category'])) {
            $idJenis = $_POST['category'];
        } else {
            $idJenis = $row['idJenis'];
        }
        if (isset($_FILES['img']) && $_FILES['img']['error'] == 0) {
            $image = file_get_contents($_FILES['img']['tmp_name']);
            $img = mysqli_real_escape_string($con, $image);
        } else {
            $img = '';
        }
        
        if (!empty($img)){
            $update = "UPDATE `produk` 
                       SET namaProduk = '$namaProduk', hargaProduk = '$harga', idJenis = '$idJenis', warnaProduk = '$warna', imejProduk = '$img'
                       WHERE idProduk = '$productId';";
        } else {
            $update = "UPDATE `produk` 
                       SET namaProduk = '$namaProduk', hargaProduk = '$harga', idJenis = '$idJenis', warnaProduk = '$warna'
                       WHERE idProduk = '$productId';";
        }

        $updateResult = mysqli_query($con, $update);

        if ($updateResult){
            echo "<script>alert('Edit successful!');</script>";
            echo "<script>localStorage.setItem('editModalDisplayState', 'none');</script>";
            echo "<script>setTimeout(function(){ window.location.href = 'admindashboard.php'; }, 10);</script>";
        } else {
            echo "<script>alert('Edit unsuccessful!');</script>";
            echo "<script>setTimeout(function(){ window.location.href = 'admindashboard.php?".$productId."'; }, 10);</script>";
        }
    }

?>