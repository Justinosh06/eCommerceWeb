<?php
include "../php/connect.php";
?>

<?php

$query = mysqli_query($con, "SELECT namaJenis FROM `jenis`");

if (!$query) {
    echo "Error: " . mysqli_error($con);
    exit();
}

echo '<div class = "filter">';
echo '<div class = "radio-section">';
echo '<div class = "icon"><i id = "left" class = "fa-solid fa-chevron-left"></i></div>';

echo '<div class = "radio-btn">';

echo '<input type = "radio" name = "PenType" value = "" id = "all" checked = "checked">';
echo '<label for = "all"><div class="dot"></div><span>All</span></label>';

while ($row = mysqli_fetch_assoc($query)) {
    foreach ($row as $key => $value) {
        if ($key == 'namaJenis'){
            echo '<input type = "radio" name = "PenType" value = "'.$value.'" id = "'.$value.'">';
            echo '<label for = "'.$value.'"><div class="dot"></div><span>'.$value.'</span></label>';
        }
    }
}

echo '</div>';

echo '<div class = "icon"><i id = "right" class = "fa-solid fa-chevron-right"></i></div>';
echo '</div>';
?>


    <div class="search-section">
    <span class="fa-solid fa-magnifying-glass" id = "search-icon"></span>
        <input type = "text" id = "search-bar" name = "search" placeholder = "Search">
    </div>

</div>