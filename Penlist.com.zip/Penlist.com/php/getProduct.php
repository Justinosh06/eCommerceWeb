<?php
// get the product id from the request
$id = $_GET['id'];

// connect to your database
// replace 'hostname', 'username', 'password', and 'database' with your database credentials
$pdo = new PDO('mysql:host=hostname;dbname=database', 'username', 'password');

// prepare a SQL query to retrieve the product data for the specified id
$stmt = $pdo->prepare('SELECT * FROM products WHERE id = :id');

// bind the id parameter to the prepared statement
$stmt->bindParam(':id', $id);

// execute the prepared statement
$stmt->execute();

// fetch the product data as an associative array
$product = $stmt->fetch(PDO::FETCH_ASSOC);

// return the product data as a JSON string
echo json_encode($product);
?>