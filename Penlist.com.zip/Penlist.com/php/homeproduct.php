<?php
include "../php/connect.php";
?>

<h2 class = "productTitle">Featured</h2>

<?php
$limit = 12;
$current_time = time();

$query = mysqli_query($con, "SELECT namaProduk, jenis.namaJenis, imejProduk, hargaProduk, idProduk FROM `produk` INNER JOIN `jenis` ON produk.idJenis = jenis.idJenis ORDER BY RAND() LIMIT $limit");

if (!$query) {
    echo "Error: " . mysqli_error($con);
    exit();
}

echo '<div class="productCards" id="productCards">';

while ($row = mysqli_fetch_assoc($query)) {
    echo "<div class='card' id='card'>";
    echo "<div class='cardHeader'>";

    foreach ($row as $key => $value) {
        if ($key == 'namaProduk') {
            echo '<h3>'.$value.'</h3>';
        } else if ($key == 'namaJenis') {
            echo '<p>'.$value.'</p>';
            echo '</div>';
        } else if ($key == 'imejProduk') {
            echo '<div class="cardImg">';
            echo '<img src="data:image/png;base64,'.base64_encode($value).'" alt="...">';
            echo '</div>';
        } else if ($key == 'hargaProduk') {
            echo '<div class="cardDetails">';
            echo '<div class="price">';
            echo '<p>Price</p>';
            echo '<strong>RM '.$value.'</strong>';
            echo '</div>';
        }
        else if ($key == 'idProduk'){
            if ($_SESSION['logged_in'] == true){
                echo '<form action = "../php/addToCart.php" method = "post">';
                echo '<input type = "hidden" value = "index.php" name = "location">';
                echo '<input type = "hidden" value = "'.$value.'" id = "idProduct" name = "idProduct">';
                echo '<button id = "add-to-cart">Add to cart</button>';
                echo '</form>';
            }
        }
    }

    
    echo '</div>';
    echo '</div>';
}

echo '</div>';
?>