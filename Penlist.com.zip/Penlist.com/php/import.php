<?php
    include '../php/connect.php';

// check if a file was uploaded
if (isset($_FILES['csv_file']) && $_FILES['csv_file']['error'] == 0) {

    // get the file extension
    $file_extension = pathinfo($_FILES['csv_file']['name'], PATHINFO_EXTENSION);

    // check if the file is a CSV file
    if ($file_extension == 'csv') {

        // open the file for reading
        $file_handle = fopen($_FILES['csv_file']['tmp_name'], 'r');

        // read the file line by line
        while (($line = fgetcsv($file_handle)) !== false) {

            // get the value of the first column
            $namaJenis = $line[0];

            // escape special characters in the value
            $namaJenis = mysqli_real_escape_string($con, $namaJenis);

           // Check if the record already exists
           $checkSql = "SELECT * FROM jenis WHERE namaJenis = '$namaJenis'";
           $checkResult = mysqli_query($con, $checkSql);
           
           if (mysqli_num_rows($checkResult) > 0) {
               echo "<script>alert('Category $namaJenis already exists.');</script>";
           } else {
               $sql = "INSERT INTO jenis (namaJenis) VALUES ('$namaJenis')";
               $result = mysqli_query($con, $sql);


                // check if the insert was successful
                if($result){
                    // show success message in an alert box
                    echo "<script>alert('Category $namaJenis added successfully!');
                    console.log('succeed')</script>";
                } else {
                    // show error message in an alert box
                    echo "<script>alert('Error adding category $namaJenis: " . mysqli_error($con) . "');</script>";
                }
            }
        }

        // close the file handle
        fclose($file_handle);

        // redirect back to the page with a success message
        header("Location: import.php");
    }
    else {
        echo "Error: Only CSV files are allowed.";
    }
}

// close the database connection
$con->close();
?>

<!DOCTYPE HTML>
<html>
  <head>
    <meta charset = "utf-8">
    <meta name = "viewport" content = "width = device-width, initial-scale = 1.0">
    <meta http-equiv = "X-UA-Compatible" content = "IE = edge">

    <!--title-->
    <title>Import | PenList</title>
    <!--shortcut icon-->
    <link rel = "Shortcut Icon" type = "image/png" href = "../image/favicon.png">

    <link href = "https://fonts.googleapis.com" rel = "preconnect">
    <link href = "https://fonts.gstatic.com" crossorigin rel = "preconnect">

    <!--Icons Source-->
    <link rel="stylesheet" href="../fontawesome-free-6.4.0-web/css/all.min.css">

    <!--import fonts-->
    <link href = "https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800;900&display=swap" rel = "stylesheet">

    <!--import font icons-->
    <script src = "https://kit.fontawesome.com/f3ce044c74.js" crossorigin = "anonymous"></script>
    <link rel = "stylesheet" href = "https://kit.fontawesome.com/f3ce044c74.css" crossorigin = "anonymous">

    <!--link to external css file-->
    <link href = "../css/admindashboard.css" rel = "stylesheet">
    <link href = "../css/adminNavbar.css" rel = "stylesheet">
    <link href = "../css/import.css" rel = "stylesheet">


  </head>
  <body>

    <div class="navbar">
        <?php
        include "../html/adminNavbar.html";
        ?>
    </div>

    <section class="dashboard">

        <?php
        include "../html/adminTop.html";
        ?>
        
        <div class="main">
            <span class="title"><i class="fa-solid fa-download"></i>Import</span>
            
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" enctype="multipart/form-data">
                <div class="div" id="drop-zone">
                    <label for="csv_file" class="custom-file-upload"><span>Drag and drop your file here<span></label>
                </div>
                <input type="file" accept=".csv" name="csv_file" id = "csv_file">
                <input type="submit" value="Import">
            </form>

            <div class="tableflex">
                <table>
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Category</th>
                            <th></th>
                        </tr>
                    </thead>
                    <?php include("../php/importFile.php"); ?>
                </table>
            </div>
        </div>

    </section>
    <script type="text/javascript" src = "../js/themeToggle.js"></script>
    <script type="text/javascript" src = "../js/adminNavbar.js"></script>
    <script type="text/javascript" src = "../js/import.js"></script>
  </body>
</html>

<script>
    const dropZone = document.getElementById('drop-zone');
    const fileInput = document.getElementById('csv_file');

    ['dragover', 'dragenter'].forEach(eventName => {
    dropZone.addEventListener(eventName, e => {
        e.preventDefault();
        dropZone.classList.add('highlight');
    }, false);
    });

    ['dragleave', 'dragend'].forEach(eventName => {
    dropZone.addEventListener(eventName, e => {
        e.preventDefault();
        dropZone.classList.remove('highlight');
    }, false);
    });

    dropZone.addEventListener('drop', e => {
        e.preventDefault();
        dropZone.classList.remove('highlight');
        const file = e.dataTransfer.files[0];
        fileInput.files = e.dataTransfer.files;
        fileInput.dispatchEvent(new Event('change'));
    }, false);
</script>