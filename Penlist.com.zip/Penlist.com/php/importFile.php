<?php
include '../php/connect.php';

// Retrieve data from the database
$sql = "SELECT * FROM jenis;";
$result = mysqli_query($con, $sql);
$resultCheck = mysqli_num_rows($result);

// Check if there are any results
if ($resultCheck > 0){
    $number = 1;
    echo '<tbody>';
    while($row = mysqli_fetch_assoc($result)){
        // Display each row in a table
        ?>
        <tr>
            <td><?php echo $number ?></td>
            <td><?php echo $row['namaJenis']; ?></td>
            <td><button class="delete-category" onclick="deleteCategory('<?php echo $row['idJenis']; ?>')">
            <i class="fa-solid fa-trash"></i></button></td>
        </tr>
        <?php 
        $number++;
    }
    echo '</tbody>';
}
?>
