<!DOCTYPE HTML>
<html>
  <head>
    <meta charset = "utf-8">
    <meta name = "viewport" content = "width = device-width, initial-scale = 1.0">
    <meta http-equiv = "X-UA-Compatible" content = "IE = edge">

    <!--title-->
    <title>Homepage | PenList</title>
    <!--shortcut icon-->
    <link rel = "Shortcut Icon" type = "image/png" href = "../image/favicon.png">

    <link href = "https://fonts.googleapis.com" rel = "preconnect">
    <link href = "https://fonts.gstatic.com" crossorigin rel = "preconnect">

    <!--Icons Source-->
    <link rel="stylesheet" href="../fontawesome-free-6.4.0-web/css/all.min.css">

    <!--import fonts-->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">


    <!--link to external css file-->
    <link href = "../css/index.css" rel = "stylesheet">
    <link href = "../css/banner.css" rel = "stylesheet">
    <link href = "../css/navbar.css" rel = "stylesheet">
    <link href = "../css/searchbar.css" rel = "stylesheet">
    <link href = "../css/product.css" rel = "stylesheet">
    <link href = "../css/footer.css" rel = "stylesheet">
  </head>
  <body>
    <div class = "navigationBar">
      <?php
      include "../php/navbar.php";
      ?>
    </div>

    <div class = "banner">
      <?php
      include "../html/banner.html";
      ?>
    </div>

    <section class = "product" id = "product">
        <?php
        include "../php/homeproduct.php";
        ?>
    </section>

    <footer>
      <?php
      include "../html/footer.html";
      ?>
    </footer>

    <script type = "text/javascript" src = "../js/banner.js"></script>
    <script type = "text/javascript" src = "../js/index.js"></script>
    <script type = "text/javascript" src = "../js/loginIdenfication.js"></script>

  </body>
</html>
