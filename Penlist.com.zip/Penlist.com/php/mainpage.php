<?php 
include "../php/connect.php";
?>

<!DOCTYPE HTML>
<html>
  <head>
    <meta charset = "utf-8">
    <meta name = "viewport" content = "width = device-width, initial-scale = 1.0">
    <meta http-equiv = "X-UA-Compatible" content = "IE = edge">

    <!--title-->
    <title>Login | PenList</title>
    <!--shortcut icon-->
    <link rel = "Shortcut Icon" type = "image/png" href = "../image/favicon.png">

    <link href = "https://fonts.googleapis.com" rel = "preconnect">
    <link href = "https://fonts.gstatic.com" crossorigin rel = "preconnect">

    <!--import fonts-->
    <link href = "https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800;900&display=swap" rel = "stylesheet">

    <!--import font icons-->
    <link rel="stylesheet" href="../fontawesome-free-6.4.0-web/css/all.min.css">

    <!--link to external css file-->
    <link href = "../css/mainpage.css" rel = "stylesheet">
  </head>
  <body>

    <div class = "wrapper">
      <?php
      include "../html/mainpageDecor.html";
      ?>
    </div>

    <div class = "description">
      <div class = "welcome">
        <div class = "title">
          <h1>Welcome to</h1>
          <img src = "../image/Penlist_logo_blk.png">
        </div>
      </div>

    </div>

    <!--login and register-->
    <div class = "main">
	    <input type = "checkbox" id = "chk" aria-hidden = "true">

      <div class = "login">
        <form id = "Login" action = "../php/mainpage.php" method = "POST">
          <label for = "chk" aria-hidden = "true">Login</label>
          <input type = "email" id = "emailLogin" name = "login_email" placeholder = "Email" oninput = "setCustomValidity('')" oninvalid = "setCustomValidity('Please fill in!')" pattern = ".{1, }" onkeydown = "validationLogin()">
          <span id = "textLogin"></span>
          <input type = "password" name = "login_pswd" placeholder = "Password" title = "8-16 characters" pattern = ".{8,16}" oninvalid = "setCustomValidity('Password between 8 - 16 charcters')" oninput = "setCustomValidity('')" id = "pswd-login">
          <button name = "Login">Login</button>
        </form>
        <button id="pswd-visibility-login" onclick="togglePasswordVisibility('login-pswd')"><i class="fa-solid fa-eye-slash"></i></button>
      </div>

			<div class = "signup">
				<form id = "Signup" action = "../php/mainpage.php" method = "POST" enctype = "multipart/form-data">
					<label for = "chk" aria-hidden = "true">Sign up</label>
					<input type = "text" name = "signup_username" placeholder = "Username" max-length = "20" oninput = "setCustomValidity('')" oninvalid = "setCustomValidity('Please fill in!')" pattern = ".{1, }">
					<input type = "email" id = "emailSignup" name = "signup_email" placeholder = "Email" onkeydown = "validationSignup()" oninput = "setCustomValidity('')" oninvalid = "setCustomValidity('Please fill in!')" pattern = ".{1, }">
          <span id = "textSignup"></span>
					<input type = "password" name = "signup_pswd" placeholder = "Password" title = "8-16 characters" pattern = ".{8,16}" oninvalid = "setCustomValidity('Password between 8 - 16 charcters')" oninput = "setCustomValidity('')" id = "pswd-signup">
					<button name = "Signup">Signup</button>
				</form>
        <button id="pswd-visibility-signup" onclick="togglePasswordVisibility('signup-pswd')"><i class="fa-solid fa-eye-slash"></i></button>
			</div>
	  </div>

  </body>

  <script type = "text/javascript" src = "../js/mainpage.js"></script>
  <script type = "text/javascript" src = "../js/password.js"></script>
</html>

<!-- php code -->
<?php
//signup
if(isset($_POST["Signup"])){
  $signup_username = $_POST["signup_username"];
  $signup_email = $_POST["signup_email"];
  $signup_pswd = $_POST["signup_pswd"];

  //select query
  $select_query = "SELECT * FROM pengguna WHERE emelPengguna = '$signup_email'";
  $result = mysqli_query($con, $select_query);
  $rows_count = mysqli_num_rows($result);
  if($rows_count > 0){
    echo "<script>alert('Username already exist');</script>";
  }
  else{
  //insert_query
  $sql_execute = mysqli_query($con, "INSERT INTO pengguna (namaPengguna, emelPengguna, kataLaluanPengguna) VALUES ('$signup_username', '$signup_email', '$signup_pswd')");

  if($sql_execute){
    echo "<script>alert('Data inserted successfully');</script>";
  } else{
    die(mysqli_error($con));
  }
}
}
?>

<!--login-->
<?php
  if (isset($_POST['Login'])) {
    // Step 3: Retrieve the username and password entered by the user
    $login_email = $_POST['login_email'];
    $login_password = $_POST['login_pswd'];

    // Step 4: Query the user table to retrieve the user's information
    $user_query = mysqli_query($con, "SELECT * FROM `pengguna` WHERE emelPengguna = '$login_email' AND kataLaluanPengguna = '$login_password'");
    $user_row = mysqli_fetch_array($user_query);

    // Step 5: Check if the user is an admin
    if ($user_row) {
        $_SESSION['user_id'] = $user_row['idPengguna'];
        $_SESSION['user_email'] = $user_row['emelPengguna'];
        $_SESSION['user_pass'] = $user_row['kataLaluanPengguna'];

        echo '<script type="text/javascript">';
        echo 'alert("login successfully");';
        echo 'window.location.href = "index.php";';
        echo '</script>';
        exit();
    } else {
        $admin_query = mysqli_query($con, "SELECT * FROM `admin` WHERE emelAdmin = '$login_email' AND kataLaluanAdmin = '$login_password'");
        $admin_row = mysqli_fetch_array($admin_query);

        if ($admin_row) {
            // Grant access to the admin area
            // Redirect the user to the admin area
            $_SESSION['admin_id'] = $admin_row['idAdmin'];
            $_SESSION['admin_email'] = $admin_row['emelAdmin'];
            $_SESSION['admin_pass'] = $admin_row['kataLaluanAdmin'];

            echo '<script type="text/javascript">';
            echo 'alert("login successfully");';
            echo 'window.location.href = "admindashboard.php";';
            echo '</script>';
            exit();
        } else {
            $_SESSION['isloggedin'] = false;

            echo '<script language="javascript">';
            echo 'alert("invalid email address and password");';
            echo '</script>';
        }
    }
  }
?>
