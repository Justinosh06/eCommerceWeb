<?php
include '../php/connect.php';

if (isset($_SESSION['user_email'])) {
    $_SESSION['logged_in'] = true;
} else {
    $_SESSION['logged_in'] = false;
}
?>

<header>


    <img src = "../image/Penlist_logo_blk.png" alt = "" class = "logo">

    <nav>
        <ul>
            <li><a href = "../php/#">home</a></li>
            <li><a href = "../php/#product">product</a></li>
        </ul>
    </nav>

    <a href = "../php/searchpage.php" class = "searchpage">
        <span class="fa-solid fa-magnifying-glass"></span>
    </a>

    <?php
if ($_SESSION['logged_in'] == true){
    echo '<a href = "../php/mainpage.php" id = "login-li" style = "display: none"><button class = "login">Login</button></a>';
    echo '<a href = "../php/cart.php" id = "cart.li" style = "display: block"><button class = "cart"><i class="fa-solid fa-cart-shopping"></i>cart</button></a>';
    echo '<a href = "../php/logout.php"><i class="fa-solid fa-arrow-right-from-bracket" style = "display: block"></i></a>';
} else if ($_SESSION['logged_in'] == false) {
    echo '<a href = "../php/mainpage.php" id = "login-li" style = "display: block"><button class = "login">Login</button></a>';
    echo '<a href = "../php/cart.php" id = "cart.li" style = "display: none"><button class = "cart"><i class="fa-solid fa-cart-shopping"></i>cart</button></a>';
    echo '<a href = "../php/logout.php"><i class="fa-solid fa-arrow-right-from-bracket" style = "display: none"></i></a>';
} else {
    echo '<a href = "../php/mainpage.php" id = "login-li" style = "display: block"><button class = "login">Login</button></a>';
    echo '<a href = "../php/cart.php" id = "cart.li" style = "display: none"><button class = "cart"><i class="fa-solid fa-cart-shopping"></i>cart</button></a>';
    echo '<a href = "../php/logout.php"><i class="fa-solid fa-arrow-right-from-bracket" style = "display: none"></i></a>';
}
?>

</header>