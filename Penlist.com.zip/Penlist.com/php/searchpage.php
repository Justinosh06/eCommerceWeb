<!DOCTYPE HTML>
<html>
  <head>
    <meta charset = "utf-8">
    <meta name = "viewport" content = "width = device-width, initial-scale = 1.0">
    <meta http-equiv = "X-UA-Compatible" content = "IE = edge">

    <!--title-->
    <title>Searchpage | PenList</title>
    <!--shortcut icon-->
    <link rel = "Shortcut Icon" type = "image/png" href = "../image/favicon.png">

    <link href = "https://fonts.googleapis.com" rel = "preconnect">
    <link href = "https://fonts.gstatic.com" crossorigin rel = "preconnect">

    <!--Icons Source-->
    <link rel="stylesheet" href="../fontawesome-free-6.4.0-web/css/all.min.css">

    <!--import fonts-->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">

    <!--link to external css file-->
    <link href = "../css/navbar.css" rel = "stylesheet">
    <link href = "../css/searchpage.css" rel = "stylesheet">
    <link href = "../css/backtotop.css" rel = "stylesheet">
    <link href = "../css/filter.css" rel = "stylesheet">
    <link href = "../css/product.css" rel = "stylesheet">
    <link href = "../css/footer.css" rel = "stylesheet">
  </head>
  <body>

    <div class = "navbar">
      <?php
      include "../php/navbar.php";
      ?>
    </div>

    <section id = "products">
        
        <div class="filter-section">
          <?php
          include "../php/filter.php";
          ?>
        </div>

        <div class = "product cards">
              <?php
              include "../php/product.php";
              ?>
        </div>
    </section>

    <footer>
      <?php
      include "../html/footer.html";
      ?>
    </footer>


    <script type = "text/javascript" src = "../js/navbar.js"></script>
    <script type = "text/javascript" src = "../js/search.js"></script>
    <script type = "text/javascript" src = "../js/filter.js"></script>

  </body>
</html>
